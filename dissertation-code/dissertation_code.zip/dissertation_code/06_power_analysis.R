# =============================================================================
# SENSITIVITY POWER ANALYSIS
# Minimum Detectable Effect Sizes for Fixed Sample Size
# =============================================================================

library(pwr)
library(WebPower)
library(ggplot2)

# =============================================================================
# BASIC SENSITIVITY POWER ANALYSIS
# =============================================================================

sensitivity_power <- function(n, alpha = 0.05, power_levels = c(0.80, 0.90, 0.95)) {
  
  results <- data.frame(
    power = power_levels,
    min_r = NA,    # correlation
    min_f2 = NA,   # Cohen's f² for regression
    min_d = NA     # Cohen's d
  )
  
  for (i in seq_along(power_levels)) {
    # Minimum detectable correlation
    results$min_r[i] <- pwr.r.test(n = n, power = power_levels[i], 
                                    sig.level = alpha)$r
    
    # Minimum detectable f² (for regression with ~8 predictors)
    results$min_f2[i] <- pwr.f2.test(u = 8, v = n - 9, power = power_levels[i],
                                      sig.level = alpha)$f2
    
    # Minimum detectable d (two-group comparison)
    results$min_d[i] <- pwr.t.test(n = n/2, power = power_levels[i],
                                    sig.level = alpha, type = "two.sample")$d
  }
  
  results
}

# =============================================================================
# REGRESSION-SPECIFIC POWER ANALYSIS (for individual coefficients)
# =============================================================================

sensitivity_power_regression <- function(n_obs, n_predictors, n_way_interaction = 0,
                                          power_levels = c(0.80, 0.90, 0.95),
                                          alpha = 0.05) {
  
  # Build formula for display
  main_effects <- paste0("x", 1:n_predictors, collapse = " + ")
  if (n_way_interaction > 0) {
    interaction_term <- paste0("x", 1:n_way_interaction, collapse = ":")
    formula_str <- paste0("y ~ ", main_effects, " + ", interaction_term)
  } else {
    formula_str <- paste0("y ~ ", main_effects)
  }
  
  # Total predictors in model
  total_predictors <- n_predictors + ifelse(n_way_interaction > 0, 1, 0)
  
  cat("Formula:", formula_str, "\n")
  cat("Sample size:", n_obs, "\n")
  cat("Total model predictors:", total_predictors, "\n\n")
  
  # Solve for minimum detectable f² for a single coefficient
  results <- data.frame(power = power_levels, min_f2 = NA, min_delta_R2 = NA)
  
  for (i in seq_along(power_levels)) {
    # p1 = total predictors, p2 = 1 (testing single coefficient)
    res <- wp.regression(n = n_obs, p1 = total_predictors, p2 = 1, 
                         f2 = NULL, alpha = alpha, power = power_levels[i])
    results$min_f2[i] <- round(res$f2, 4)
    results$min_delta_R2[i] <- round(res$f2 / (1 + res$f2), 4)
  }
  
  print(results, row.names = FALSE)
  invisible(results)
}

# =============================================================================
# POWER FOR BETA COEFFICIENTS
# =============================================================================

power_for_beta <- function(n_obs, n_predictors, beta_values = seq(0.05, 0.25, by = 0.05),
                            alpha = 0.05, r_squared_model = 0.15) {
  
  df_residual <- n_obs - n_predictors - 1
  
  results <- data.frame(
    beta = beta_values,
    power = NA
  )
  
  for (i in seq_along(beta_values)) {
    beta <- beta_values[i]
    # Convert standardized beta to f² for a single coefficient
    f2 <- beta^2 / (1 - r_squared_model)
    res <- pwr.f2.test(u = 1, v = df_residual, f2 = f2, sig.level = alpha)
    results$power[i] <- round(res$power, 3)
  }
  
  return(results)
}

# Solve for minimum detectable beta at given power
min_detectable_beta <- function(n_obs, n_predictors, target_power = 0.80, 
                                 alpha = 0.05, r_squared_model = 0.15) {
  
  df_residual <- n_obs - n_predictors - 1
  
  # Get minimum f2
  min_f2 <- pwr.f2.test(u = 1, v = df_residual, power = target_power, 
                        sig.level = alpha)$f2
  
  # Convert f2 to beta: f2 = beta^2 / (1 - R2) => beta = sqrt(f2 * (1 - R2))
  min_beta <- sqrt(min_f2 * (1 - r_squared_model))
  
  return(round(min_beta, 3))
}

# =============================================================================
# RUN ANALYSES FOR YOUR SAMPLE SIZES
# =============================================================================

cat("=============================================================================\n")
cat("SENSITIVITY POWER ANALYSIS FOR MIDUS DISSERTATION\n")
cat("=============================================================================\n\n")

# Your analytic sample sizes (dual-earner couples)
n_midus2 <- 1300  # Adjust based on actual analytic sample
n_midus3 <- 670   # Adjust based on actual analytic sample

cat("--- MIDUS II (n =", n_midus2, ") ---\n")
print(sensitivity_power(n = n_midus2))

cat("\n--- MIDUS III (n =", n_midus3, ") ---\n")
print(sensitivity_power(n = n_midus3))

cat("\n\n=============================================================================\n")
cat("MINIMUM DETECTABLE BETA AT 80% AND 90% POWER\n")
cat("=============================================================================\n\n")

# Main effects model (~8 predictors)
cat("Main effect models (8 predictors):\n")
cat("MIDUS II - 80% power: β =", min_detectable_beta(n_midus2, 8, 0.80), "\n")
cat("MIDUS II - 90% power: β =", min_detectable_beta(n_midus2, 8, 0.90), "\n")
cat("MIDUS III - 80% power: β =", min_detectable_beta(n_midus3, 8, 0.80), "\n")
cat("MIDUS III - 90% power: β =", min_detectable_beta(n_midus3, 8, 0.90), "\n")

# Interaction models (~9 predictors)
cat("\nInteraction models (9 predictors):\n")
cat("MIDUS II - 80% power: β =", min_detectable_beta(n_midus2, 9, 0.80), "\n")
cat("MIDUS II - 90% power: β =", min_detectable_beta(n_midus2, 9, 0.90), "\n")
cat("MIDUS III - 80% power: β =", min_detectable_beta(n_midus3, 9, 0.80), "\n")
cat("MIDUS III - 90% power: β =", min_detectable_beta(n_midus3, 9, 0.90), "\n")

# =============================================================================
# POWER CURVE VISUALIZATION
# =============================================================================

create_power_curve <- function(n_obs, n_predictors, sample_name) {
  betas <- seq(0.05, 0.30, by = 0.01)
  powers <- sapply(betas, function(b) {
    f2 <- b^2 / 0.85  # Assuming R² = 0.15
    pwr.f2.test(u = 1, v = n_obs - n_predictors - 1, f2 = f2, sig.level = 0.05)$power
  })
  
  data.frame(beta = betas, power = powers, sample = sample_name)
}

# Create power curves
power_m2 <- create_power_curve(n_midus2, 9, "MIDUS II")
power_m3 <- create_power_curve(n_midus3, 9, "MIDUS III")
power_data <- rbind(power_m2, power_m3)

# Plot
ggplot(power_data, aes(x = beta, y = power, color = sample)) +
  geom_line(size = 1.2) +
  geom_hline(yintercept = 0.80, linetype = "dashed", alpha = 0.5) +
  geom_hline(yintercept = 0.90, linetype = "dashed", alpha = 0.5) +
  scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.1)) +
  labs(
    title = "Power to Detect Standardized Beta Coefficients",
    subtitle = "Interaction models with 9 predictors",
    x = "Standardized Beta (β)",
    y = "Statistical Power",
    color = "Sample"
  ) +
  theme_minimal() +
  theme(legend.position = "bottom")
