# =============================================================================
# MIDUS DISSERTATION ANALYSIS - REGRESSION MODELS
# Executive Functioning and Work-Family Spillover
# MIDUS 2 and MIDUS 3
# =============================================================================

# =============================================================================
# MIDUS 2 - MAIN EFFECTS (H1-H4)
# =============================================================================

m1_negwf_m2 <- lm(B1SNEGWF ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                   B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)

m2_negfw_m2 <- lm(B1SNEGFW ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                   B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)

m3_poswf_m2 <- lm(B1SPOSWF ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                   B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)

m4_posfw_m2 <- lm(B1SPOSFW ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                   B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)

# =============================================================================
# MIDUS 3 - MAIN EFFECTS (H1-H4)
# =============================================================================

m1_negwf_m3 <- lm(C1SNEGWF ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                   C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)

m2_negfw_m3 <- lm(C1SNEGFW ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                   C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)

m3_poswf_m3 <- lm(C1SPOSWF ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                   C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)

m4_posfw_m3 <- lm(C1SPOSFW ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                   C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)

# =============================================================================
# MIDUS 2 - GENDER MODERATION (H5-H6, RQ1-RQ2)
# =============================================================================

m5_gender_negfw_m2 <- lm(B1SNEGFW ~ B3TEFZ1_c * B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

m6_gender_negwf_m2 <- lm(B1SNEGWF ~ B3TEFZ1_c * B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

m7_gender_posfw_m2 <- lm(B1SPOSFW ~ B3TEFZ1_c * B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

m8_gender_poswf_m2 <- lm(B1SPOSWF ~ B3TEFZ1_c * B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

# =============================================================================
# MIDUS 3 - GENDER MODERATION (H5-H6, RQ1-RQ2)
# =============================================================================

m5_gender_negfw_m3 <- lm(C1SNEGFW ~ C3TEF_c * C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

m6_gender_negwf_m3 <- lm(C1SNEGWF ~ C3TEF_c * C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

m7_gender_posfw_m3 <- lm(C1SPOSFW ~ C3TEF_c * C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

m8_gender_poswf_m3 <- lm(C1SPOSWF ~ C3TEF_c * C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

# =============================================================================
# MIDUS 2 - SUPERVISOR SUPPORT MODERATION (H7-H8, RQ3-RQ4)
# =============================================================================

m9_super_negfw_m2 <- lm(B1SNEGFW ~ B3TEFZ1_c * B1SJCSS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                         B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                        data = df_m2_analytic)

m10_super_negwf_m2 <- lm(B1SNEGWF ~ B3TEFZ1_c * B1SJCSS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

m11_super_posfw_m2 <- lm(B1SPOSFW ~ B3TEFZ1_c * B1SJCSS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

m12_super_poswf_m2 <- lm(B1SPOSWF ~ B3TEFZ1_c * B1SJCSS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                          B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                         data = df_m2_analytic)

# =============================================================================
# MIDUS 3 - SUPERVISOR SUPPORT MODERATION (H7-H8, RQ3-RQ4)
# =============================================================================

m9_super_negfw_m3 <- lm(C1SNEGFW ~ C3TEF_c * C1SJCSS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                         C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                        data = df_m3_analytic)

m10_super_negwf_m3 <- lm(C1SNEGWF ~ C3TEF_c * C1SJCSS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

m11_super_posfw_m3 <- lm(C1SPOSFW ~ C3TEF_c * C1SJCSS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

m12_super_poswf_m3 <- lm(C1SPOSWF ~ C3TEF_c * C1SJCSS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                          C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                         data = df_m3_analytic)

# =============================================================================
# MIDUS 2 - COWORKER SUPPORT MODERATION (H9-H10, RQ5-RQ6)
# =============================================================================

m13_cowork_negfw_m2 <- lm(B1SNEGFW ~ B3TEFZ1_c * B1SJCCS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

m14_cowork_negwf_m2 <- lm(B1SNEGWF ~ B3TEFZ1_c * B1SJCCS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

m15_cowork_posfw_m2 <- lm(B1SPOSFW ~ B3TEFZ1_c * B1SJCCS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

m16_cowork_poswf_m2 <- lm(B1SPOSWF ~ B3TEFZ1_c * B1SJCCS_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

# =============================================================================
# MIDUS 3 - COWORKER SUPPORT MODERATION (H9-H10, RQ5-RQ6)
# =============================================================================

m13_cowork_negfw_m3 <- lm(C1SNEGFW ~ C3TEF_c * C1SJCCS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

m14_cowork_negwf_m3 <- lm(C1SNEGWF ~ C3TEF_c * C1SJCCS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

m15_cowork_posfw_m3 <- lm(C1SPOSFW ~ C3TEF_c * C1SJCCS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

m16_cowork_poswf_m3 <- lm(C1SPOSWF ~ C3TEF_c * C1SJCCS_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

# =============================================================================
# MIDUS 2 - SPOUSAL SUPPORT MODERATION (H11-H12, RQ7-RQ8)
# =============================================================================

m17_spouse_negfw_m2 <- lm(B1SNEGFW ~ B3TEFZ1_c * B1SSPEMP_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

m18_spouse_negwf_m2 <- lm(B1SNEGWF ~ B3TEFZ1_c * B1SSPEMP_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

m19_spouse_posfw_m2 <- lm(B1SPOSFW ~ B3TEFZ1_c * B1SSPEMP_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

m20_spouse_poswf_m2 <- lm(B1SPOSWF ~ B3TEFZ1_c * B1SSPEMP_c + B1PGENDER + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                           B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PB1,
                          data = df_m2_analytic)

# =============================================================================
# MIDUS 3 - SPOUSAL SUPPORT MODERATION (H11-H12, RQ7-RQ8)
# =============================================================================

m17_spouse_negfw_m3 <- lm(C1SNEGFW ~ C3TEF_c * C1SSPEMP_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

m18_spouse_negwf_m3 <- lm(C1SNEGWF ~ C3TEF_c * C1SSPEMP_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

m19_spouse_posfw_m3 <- lm(C1SPOSFW ~ C3TEF_c * C1SSPEMP_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)

m20_spouse_poswf_m3 <- lm(C1SPOSWF ~ C3TEF_c * C1SSPEMP_c + C1PGENDER + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                           C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PB1,
                          data = df_m3_analytic)
