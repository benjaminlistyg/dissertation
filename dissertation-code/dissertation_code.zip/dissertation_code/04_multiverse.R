# =============================================================================
# MIDUS DISSERTATION - MULTIVERSE ANALYSIS
# Robustness Checks per Preregistration Amendment
# =============================================================================
# Decision points (arms):
# (a) Covariates: with/without; alternative operationalizations
# (b) Covariate specification: covariates as moderators
# (c) Inclusion criteria: alternative employment specifications
# =============================================================================

library(tidyverse)
library(broom)

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

extract_results <- function(model, model_name, specification) {
  tidy(model) %>%
    filter(str_detect(term, "TEF|EF")) %>%
    mutate(
      model = model_name,
      specification = specification,
      r_squared = summary(model)$r.squared,
      adj_r_squared = summary(model)$adj.r.squared,
      n = nobs(model)
    )
}

# =============================================================================
# ARM (A): COVARIATE VARIATIONS - MIDUS 2
# =============================================================================

# A1: No covariates
m1_nocov_m2 <- lm(B1SNEGWF ~ B3TEFZ1, data = df_m2_analytic)
m2_nocov_m2 <- lm(B1SNEGFW ~ B3TEFZ1, data = df_m2_analytic)
m3_nocov_m2 <- lm(B1SPOSWF ~ B3TEFZ1, data = df_m2_analytic)
m4_nocov_m2 <- lm(B1SPOSFW ~ B3TEFZ1, data = df_m2_analytic)

# A2: Demographics only (no job/family demands)
m1_demog_m2 <- lm(B1SNEGWF ~ B3TEFZ1 + B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)
m2_demog_m2 <- lm(B1SNEGFW ~ B3TEFZ1 + B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)
m3_demog_m2 <- lm(B1SPOSWF ~ B3TEFZ1 + B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)
m4_demog_m2 <- lm(B1SPOSFW ~ B3TEFZ1 + B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)

# A3: Work hours instead of self-report job demands (verify B1SPWKHR exists)
m1_hours_m2 <- lm(B1SNEGWF ~ B3TEFZ1 + B1SPWKHR + FAM_DEMANDS_M2 + 
                    B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)
m2_hours_m2 <- lm(B1SNEGFW ~ B3TEFZ1 + B1SPWKHR + FAM_DEMANDS_M2 + 
                    B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)
m3_hours_m2 <- lm(B1SPOSWF ~ B3TEFZ1 + B1SPWKHR + FAM_DEMANDS_M2 + 
                    B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)
m4_hours_m2 <- lm(B1SPOSFW ~ B3TEFZ1 + B1SPWKHR + FAM_DEMANDS_M2 + 
                    B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                  data = df_m2_analytic)

# A4: Education only (no income) as SES
m1_edu_m2 <- lm(B1SNEGWF ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                  B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)
m2_edu_m2 <- lm(B1SNEGFW ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                  B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)
m3_edu_m2 <- lm(B1SPOSWF ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                  B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)
m4_edu_m2 <- lm(B1SPOSFW ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                  B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)


# =============================================================================
# ARM (A): COVARIATE VARIATIONS - MIDUS 3
# =============================================================================

# A1: No covariates
m1_nocov_m3 <- lm(C1SNEGWF ~ C3TEF, data = df_m3_analytic)
m2_nocov_m3 <- lm(C1SNEGFW ~ C3TEF, data = df_m3_analytic)
m3_nocov_m3 <- lm(C1SPOSWF ~ C3TEF, data = df_m3_analytic)
m4_nocov_m3 <- lm(C1SPOSFW ~ C3TEF, data = df_m3_analytic)

# A2: Demographics only
m1_demog_m3 <- lm(C1SNEGWF ~ C3TEF + C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)
m2_demog_m3 <- lm(C1SNEGFW ~ C3TEF + C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)
m3_demog_m3 <- lm(C1SPOSWF ~ C3TEF + C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)
m4_demog_m3 <- lm(C1SPOSFW ~ C3TEF + C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)

# A3: Work hours instead of self-report job demands
m1_hours_m3 <- lm(C1SNEGWF ~ C3TEF + C1SPWKHR + FAM_DEMANDS_M3 + 
                    C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)
m2_hours_m3 <- lm(C1SNEGFW ~ C3TEF + C1SPWKHR + FAM_DEMANDS_M3 + 
                    C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)
m3_hours_m3 <- lm(C1SPOSWF ~ C3TEF + C1SPWKHR + FAM_DEMANDS_M3 + 
                    C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)
m4_hours_m3 <- lm(C1SPOSFW ~ C3TEF + C1SPWKHR + FAM_DEMANDS_M3 + 
                    C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                  data = df_m3_analytic)

# A4: Education only (no income)
m1_edu_m3 <- lm(C1SNEGWF ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                  C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)
m2_edu_m3 <- lm(C1SNEGFW ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                  C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)
m3_edu_m3 <- lm(C1SPOSWF ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                  C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)
m4_edu_m3 <- lm(C1SPOSFW ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                  C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)


# =============================================================================
# ARM (B): COVARIATES AS MODERATORS - MIDUS 2
# =============================================================================

# B1: Age x EF
m1_age_mod_m2 <- lm(B1SNEGWF ~ B3TEFZ1 * B1PAGE_M2 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                      B1STINC1 + B1PHHSIZE + B1PC4 + B1PGENDER + B1PB1, data = df_m2_analytic)
m2_age_mod_m2 <- lm(B1SNEGFW ~ B3TEFZ1 * B1PAGE_M2 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                      B1STINC1 + B1PHHSIZE + B1PC4 + B1PGENDER + B1PB1, data = df_m2_analytic)

# B2: Education x EF
m1_edu_mod_m2 <- lm(B1SNEGWF ~ B3TEFZ1 * B1PB1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                      B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER, data = df_m2_analytic)
m2_edu_mod_m2 <- lm(B1SNEGFW ~ B3TEFZ1 * B1PB1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                      B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER, data = df_m2_analytic)

# B3: Income x EF
m1_inc_mod_m2 <- lm(B1SNEGWF ~ B3TEFZ1 * B1STINC1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                      B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)
m2_inc_mod_m2 <- lm(B1SNEGFW ~ B3TEFZ1 * B1STINC1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                      B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)

# B4: Job Demands x EF
m1_jd_mod_m2 <- lm(B1SNEGWF ~ B3TEFZ1 * B1SJCDS_sum + FAM_DEMANDS_M2 + 
                     B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)
m2_jd_mod_m2 <- lm(B1SNEGFW ~ B3TEFZ1 * B1SJCDS_sum + FAM_DEMANDS_M2 + 
                     B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)

# B5: Family Demands x EF
m1_fd_mod_m2 <- lm(B1SNEGWF ~ B3TEFZ1 * FAM_DEMANDS_M2 + B1SJCDS_sum + 
                     B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)
m2_fd_mod_m2 <- lm(B1SNEGFW ~ B3TEFZ1 * FAM_DEMANDS_M2 + B1SJCDS_sum + 
                     B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1, data = df_m2_analytic)


# =============================================================================
# ARM (B): COVARIATES AS MODERATORS - MIDUS 3
# =============================================================================

# B1: Age x EF
m1_age_mod_m3 <- lm(C1SNEGWF ~ C3TEF * C1PRAGE + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                      C1STINC + C1PHHSIZE + C1PC4 + C1PGENDER + C1PB1, data = df_m3_analytic)
m2_age_mod_m3 <- lm(C1SNEGFW ~ C3TEF * C1PRAGE + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                      C1STINC + C1PHHSIZE + C1PC4 + C1PGENDER + C1PB1, data = df_m3_analytic)

# B2: Education x EF
m1_edu_mod_m3 <- lm(C1SNEGWF ~ C3TEF * C1PB1 + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                      C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER, data = df_m3_analytic)
m2_edu_mod_m3 <- lm(C1SNEGFW ~ C3TEF * C1PB1 + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                      C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER, data = df_m3_analytic)

# B3: Income x EF
m1_inc_mod_m3 <- lm(C1SNEGWF ~ C3TEF * C1STINC + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                      C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)
m2_inc_mod_m3 <- lm(C1SNEGFW ~ C3TEF * C1STINC + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                      C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)

# B4: Job Demands x EF
m1_jd_mod_m3 <- lm(C1SNEGWF ~ C3TEF * C1SJCDS_sum + FAM_DEMANDS_M3 + 
                     C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)
m2_jd_mod_m3 <- lm(C1SNEGFW ~ C3TEF * C1SJCDS_sum + FAM_DEMANDS_M3 + 
                     C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)

# B5: Family Demands x EF
m1_fd_mod_m3 <- lm(C1SNEGWF ~ C3TEF * FAM_DEMANDS_M3 + C1SJCDS_sum + 
                     C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)
m2_fd_mod_m3 <- lm(C1SNEGFW ~ C3TEF * FAM_DEMANDS_M3 + C1SJCDS_sum + 
                     C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1, data = df_m3_analytic)


# =============================================================================
# ARM (C): ALTERNATIVE INCLUSION CRITERIA
# =============================================================================

# C1: Respondent employed only (no spouse requirement)
df_m2_resp_only <- df_m2 %>% filter(B1SF13 == 1)
df_m3_resp_only <- df_m3 %>% filter(C1SF24 == 1)

m1_resp_m2 <- lm(B1SNEGWF ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                   B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
                 data = df_m2_resp_only)
m1_resp_m3 <- lm(C1SNEGWF ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                   C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
                 data = df_m3_resp_only)

# C2: Full-time employed only (35+ hours/week)
df_m2_fulltime <- df_m2_analytic %>% filter(B1SPWKHR >= 35)
df_m3_fulltime <- df_m3_analytic %>% filter(C1SPWKHR >= 35)

m1_ft_m2 <- lm(B1SNEGWF ~ B3TEFZ1 + B1SJCDS_sum + FAM_DEMANDS_M2 + 
                 B1STINC1 + B1PHHSIZE + B1PC4 + B1PAGE_M2 + B1PGENDER + B1PB1,
               data = df_m2_fulltime)
m1_ft_m3 <- lm(C1SNEGWF ~ C3TEF + C1SJCDS_sum + FAM_DEMANDS_M3 + 
                 C1STINC + C1PHHSIZE + C1PC4 + C1PRAGE + C1PGENDER + C1PB1,
               data = df_m3_fulltime)


# =============================================================================
# SPECIFICATION CURVE VISUALIZATION
# =============================================================================

create_spec_curve <- function(results_df) {
  ggplot(results_df, aes(x = reorder(specification, estimate), y = estimate)) +
    geom_point() +
    geom_errorbar(aes(ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error), width = 0.2) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
    coord_flip() +
    facet_wrap(~outcome) +
    labs(
      title = "Multiverse Analysis: EF Effect Across Specifications",
      x = "Specification",
      y = "Standardized Coefficient (95% CI)"
    ) +
    theme_minimal()
}
