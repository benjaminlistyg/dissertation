# =============================================================================
# MIDUS DISSERTATION ANALYSIS - DATA READING
# Step 1: Read in all variables needed for scoring and regressions
# =============================================================================

library(haven)
library(tidyr)
library(dplyr)
library(purrr)
library(tidylog)

# =============================================================================
# READ RAW DATA FILES
# =============================================================================

M2 <- haven::read_sav('M2_P1_SURVEY_N4963_20200720.sav')
M2_BTACT <- haven::read_sav('M2_P3_BTACT_N4512_20211123.sav')
M3 <- haven::read_sav('M3_P1_SURVEY_N3294_20181219.sav')
M3_BTACT <- haven::read_sav('M3_P3_BTACT_N3291_20210922.sav')

# =============================================================================
# MIDUS 2 - SELECT ALL REQUIRED VARIABLES
# =============================================================================

M2_selected <- M2 %>% 
  select(
    M2ID,
    
    # --- Employment filters ---
    B1SF13,        # Respondent currently working for pay
    B1PB34WK,      # Spouse/partner currently employed
    
    # --- Demographics & Controls ---
    B1PAGE_M2,     # Age
    B1PGENDER,     # Gender
    B1PB1,         # Education
    B1STINC1,      # Household income
    B1PHHSIZE,     # Total household size
    B1PC4,         # Household members (excl. children/self)
    B1PKIDHH,      # Number of children in household
    
    # --- Work-Family Spillover (pre-scored scales) ---
    B1SPOSWF,      # Positive Work-to-Family
    B1SNEGWF,      # Negative Work-to-Family
    B1SPOSFW,      # Positive Family-to-Work
    B1SNEGFW,      # Negative Family-to-Work
    
    # --- Work-Family Spillover Items (for CFA) ---
    # Positive Work-to-Family (F27e-h)
    B1SF27E, B1SF27F, B1SF27G, B1SF27H,
    # Negative Work-to-Family (F27a-d)
    B1SF27A, B1SF27B, B1SF27C, B1SF27D,
    # Positive Family-to-Work (I27m-p)
    B1SI27M, B1SI27N, B1SI27O, B1SI27P,
    # Negative Family-to-Work (I27i-l)
    B1SI27I, B1SI27J, B1SI27K, B1SI27L,
    
    # --- Job Demands Items (Section F Q28a, Q28j, Q29a, Q29c, Q29d) ---
    B1SF28A,       # Work intensively
    B1SF28J,       # Work demands hard to combine
    B1SF29A,       # Time to get everything done at work
    B1SF29C,       # Too many demands at work (R)
    B1SF29D,       # Lot of interruptions at work
    
    # --- Coworker Support Items (Section F Q30a-b) ---
    B1SF30A, B1SF30B,
    
    # --- Supervisor Support Items (Section F Q30c-e) ---
    B1SF30C, B1SF30D, B1SF30E,
    
    # --- Spouse/Partner Support Items (Section L Q11a-f) ---
    B1SL11A, B1SL11B, B1SL11C, B1SL11D, B1SL11E, B1SL11F,
    
    # --- Family Demands Items ---
    # Home demands (F33a, F33c, F33d)
    B1SF33A, B1SF33C, B1SF33D,
    # Family demands (J2g, L11g)
    B1SJ2G, B1SL11G,
    
    # --- Work Hours (for multiverse) ---
    B1SPWKHR       # Hours worked per week (verify variable name)
  )

M2_BTACT_selected <- M2_BTACT %>%
  select(
    M2ID,
    B3TEFZ1        # EF Composite (z-score, national sample)
  )

# =============================================================================
# MIDUS 3 - SELECT ALL REQUIRED VARIABLES
# =============================================================================

M3_selected <- M3 %>% 
  select(
    M2ID,
    
    # --- Employment filters ---
    C1SF24,        # Respondent currently working for pay
    C1PB34WK,      # Spouse/partner currently employed
    
    # --- Demographics & Controls ---
    C1PRAGE,       # Age
    C1PGENDER,     # Gender
    C1PB1,         # Education
    C1STINC,       # Household income
    C1PHHSIZE,     # Total household size
    C1PC4,         # Household members (excl. children/self)
    C1PKIDHH,      # Number of children in household
    
    # --- Work-Family Spillover (pre-scored scales) ---
    C1SPOSWF,      # Positive Work-to-Family
    C1SNEGWF,      # Negative Work-to-Family
    C1SPOSFW,      # Positive Family-to-Work
    C1SNEGFW,      # Negative Family-to-Work
    
    # --- Work-Family Spillover Items (for CFA) ---
    # Positive Work-to-Family (F40e-h)
    C1SF40E, C1SF40F, C1SF40G, C1SF40H,
    # Negative Work-to-Family (F40a-d)
    C1SF40A, C1SF40B, C1SF40C, C1SF40D,
    # Positive Family-to-Work (F40m-p)
    C1SF40M, C1SF40N, C1SF40O, C1SF40P,
    # Negative Family-to-Work (F40i-l)
    C1SF40I, C1SF40J, C1SF40K, C1SF40L,
    
    # --- Job Demands Items (Section F Q36a, Q36j, Q42a, Q42c, Q42d) ---
    C1SF36A,       # Work intensively
    C1SF36J,       # Work demands hard to combine
    C1SF42A,       # Time to get everything done at work
    C1SF42C,       # Too many demands at work (R)
    C1SF42D,       # Lot of interruptions at work
    
    # --- Coworker Support Items (Section F Q37a-b) ---
    C1SF37A, C1SF37B,
    
    # --- Supervisor Support Items (Section F Q37c-e) ---
    C1SF37C, C1SF37D, C1SF37E,
    
    # --- Spouse/Partner Support Items (Section L Q12a-f) ---
    C1SL12A, C1SL12B, C1SL12C, C1SL12D, C1SL12E, C1SL12F,
    
    # --- Family Demands Items ---
    # Home demands (F43a, F43c, F43d)
    C1SF43A, C1SF43C, C1SF43D,
    # Family demands (J4g, L12g)
    C1SJ4G, C1SL12G,
    
    # --- Work Hours (for multiverse) ---
    C1SPWKHR       # Hours worked per week (verify variable name)
  )

M3_BTACT_selected <- M3_BTACT %>%
  select(
    M2ID,
    C3TEF          # EF Composite
  )

# =============================================================================
# MERGE SURVEY AND COGNITIVE DATA
# =============================================================================

df_m2 <- inner_join(M2_selected, M2_BTACT_selected, by = 'M2ID')
df_m3 <- inner_join(M3_selected, M3_BTACT_selected, by = 'M2ID')

# Print initial sample sizes
cat("MIDUS 2 merged sample:", nrow(df_m2), "\n")
cat("MIDUS 3 merged sample:", nrow(df_m3), "\n")
