# =============================================================================
# CFA AND MEASUREMENT INVARIANCE FOR SPILLOVER SCALES
# Tests 4-factor structure and measurement invariance across gender
# =============================================================================

library(lavaan)
library(semTools)

# =============================================================================
# DEFINE SPILLOVER ITEMS BY WAVE
# =============================================================================

# MIDUS 2 items (B1 prefix)
m2_items <- list(
  neg_wtf = c("B1SF27A", "B1SF27B", "B1SF27C", "B1SF27D"),  # Negative Work-to-Family
  pos_wtf = c("B1SF27E", "B1SF27F", "B1SF27G", "B1SF27H"),  # Positive Work-to-Family
  neg_ftw = c("B1SI27I", "B1SI27J", "B1SI27K", "B1SI27L"),  # Negative Family-to-Work
  pos_ftw = c("B1SI27M", "B1SI27N", "B1SI27O", "B1SI27P")   # Positive Family-to-Work
)

# MIDUS 3 items (C1 prefix)
m3_items <- list(
  neg_wtf = c("C1SF40A", "C1SF40B", "C1SF40C", "C1SF40D"),
  pos_wtf = c("C1SF40E", "C1SF40F", "C1SF40G", "C1SF40H"),
  neg_ftw = c("C1SF40I", "C1SF40J", "C1SF40K", "C1SF40L"),
  pos_ftw = c("C1SF40M", "C1SF40N", "C1SF40O", "C1SF40P")
)

# =============================================================================
# CFA MODEL SPECIFICATION (4-FACTOR CORRELATED MODEL)
# =============================================================================

make_cfa_model <- function(items) {
  paste0(
    "# Measurement model\n",
    "neg_wtf =~ ", paste(items$neg_wtf, collapse = " + "), "\n",
    "pos_wtf =~ ", paste(items$pos_wtf, collapse = " + "), "\n",
    "neg_ftw =~ ", paste(items$neg_ftw, collapse = " + "), "\n",
    "pos_ftw =~ ", paste(items$pos_ftw, collapse = " + "), "\n"
  )
}

cfa_model_m2 <- make_cfa_model(m2_items)
cfa_model_m3 <- make_cfa_model(m3_items)

# =============================================================================
# FUNCTION: RUN CFA
# =============================================================================

run_cfa <- function(data, model, wave_name) {
  cat("\n", strrep("=", 70), "\n")
  cat("CFA RESULTS:", wave_name, "\n")
  cat(strrep("=", 70), "\n\n")
  
  fit <- cfa(model, data = data, ordered = FALSE, std.lv = TRUE)
  
  # Model fit
  fit_indices <- fitMeasures(fit, c("chisq", "df", "pvalue", "cfi", "tli", 
                                     "rmsea", "rmsea.ci.lower", "rmsea.ci.upper", 
                                     "srmr"))
  cat("Model Fit Indices:\n")
  print(round(fit_indices, 3))
  
  # Standardized loadings
  cat("\nStandardized Factor Loadings:\n")
  std_loadings <- standardizedSolution(fit)
  loadings <- std_loadings[std_loadings$op == "=~", c("lhs", "rhs", "est.std", "se", "pvalue")]
  print(loadings, row.names = FALSE)
  
  # Factor correlations
  cat("\nFactor Correlations:\n")
  cors <- std_loadings[std_loadings$op == "~~" & std_loadings$lhs != std_loadings$rhs & 
                         std_loadings$lhs %in% c("neg_wtf", "pos_wtf", "neg_ftw", "pos_ftw"),
                       c("lhs", "rhs", "est.std", "pvalue")]
  print(cors, row.names = FALSE)
  
  return(fit)
}

# =============================================================================
# FUNCTION: MEASUREMENT INVARIANCE ACROSS GENDER
# =============================================================================

run_invariance <- function(data, model, group_var = "gender", wave_name) {
  cat("\n", strrep("=", 70), "\n")
  cat("MEASUREMENT INVARIANCE ACROSS GENDER:", wave_name, "\n")
  cat(strrep("=", 70), "\n\n")
  
  # Configural invariance (same structure)
  cat("1. Configural Invariance (same factor structure)...\n")
  fit_config <- cfa(model, data = data, group = group_var, std.lv = TRUE)
  
  # Metric invariance (equal loadings)
  cat("2. Metric Invariance (equal loadings)...\n")
  fit_metric <- cfa(model, data = data, group = group_var, std.lv = TRUE,
                    group.equal = "loadings")
  
  # Scalar invariance (equal intercepts)
  cat("3. Scalar Invariance (equal intercepts)...\n")
  fit_scalar <- cfa(model, data = data, group = group_var, std.lv = TRUE,
                    group.equal = c("loadings", "intercepts"))
  
  # Strict invariance (equal residuals)
  cat("4. Strict Invariance (equal residuals)...\n")
  fit_strict <- cfa(model, data = data, group = group_var, std.lv = TRUE,
                    group.equal = c("loadings", "intercepts", "residuals"))
  
  # Compare models
  cat("\nModel Comparison:\n")
  comparison <- compareFit(fit_config, fit_metric, fit_scalar, fit_strict)
  print(summary(comparison))
  
  # Fit indices table
  cat("\nFit Indices by Invariance Level:\n")
  models <- list(Configural = fit_config, Metric = fit_metric, 
                 Scalar = fit_scalar, Strict = fit_strict)
  
  fit_table <- data.frame(
    Model = names(models),
    CFI = sapply(models, function(x) fitMeasures(x, "cfi")),
    RMSEA = sapply(models, function(x) fitMeasures(x, "rmsea")),
    SRMR = sapply(models, function(x) fitMeasures(x, "srmr")),
    Chi_sq = sapply(models, function(x) fitMeasures(x, "chisq")),
    df = sapply(models, function(x) fitMeasures(x, "df"))
  )
  print(round(fit_table, 3), row.names = FALSE)
  
  # Delta CFI (Chen, 2007 criterion: ΔCFI < .01 supports invariance)
  cat("\nChange in CFI (Chen, 2007: ΔCFI < .01 supports invariance):\n")
  cfi_vals <- sapply(models, function(x) fitMeasures(x, "cfi"))
  delta_cfi <- c(NA, diff(cfi_vals))
  names(delta_cfi) <- names(models)
  print(round(delta_cfi, 4))
  
  return(list(configural = fit_config, metric = fit_metric, 
              scalar = fit_scalar, strict = fit_strict))
}

# =============================================================================
# USAGE EXAMPLE
# =============================================================================

# # Load and prepare data
# df_m2$gender <- factor(df_m2$B1PGENDER)  # For MIDUS 2
# df_m3$gender <- factor(df_m3$C1PGENDER)  # For MIDUS 3
# 
# # Run CFA
# fit_m2 <- run_cfa(df_m2, cfa_model_m2, "MIDUS 2")
# fit_m3 <- run_cfa(df_m3, cfa_model_m3, "MIDUS 3")
# 
# # Run measurement invariance
# inv_m2 <- run_invariance(df_m2, cfa_model_m2, "gender", "MIDUS 2")
# inv_m3 <- run_invariance(df_m3, cfa_model_m3, "gender", "MIDUS 3")

cat("\n")
cat("=============================================================================\n")
cat("SCRIPT LOADED SUCCESSFULLY\n")
cat("=============================================================================\n")
cat("\nInterpretation guidelines:\n")
cat("  - CFI > .95, RMSEA < .06, SRMR < .08 = good fit\n")
cat("  - ΔCFI < .01 between levels supports invariance (Chen, 2007)\n")
cat("  - Scalar invariance needed for valid mean comparisons across groups\n")
